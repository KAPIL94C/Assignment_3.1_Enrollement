package com.capg.training.services;

import java.sql.Connection;


public interface UserDAO {
	public Connection getConnection();

}
