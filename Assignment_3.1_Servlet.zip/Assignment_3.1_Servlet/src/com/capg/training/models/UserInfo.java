package com.capg.training.models;

public class UserInfo {
	
	private int trainingId;
	private String trainingName;
	private int AvailableSeats;
	public int getTrainingId() {
		return trainingId;
	}
	public void setTrainingId(int trainingId) {
		this.trainingId = trainingId;
	}
	@Override
	public String toString() {
		return "UserInfo [trainingId=" + trainingId + ", trainingName=" + trainingName + ", AvailableSeats="
				+ AvailableSeats + "]";
	}
	public String getTrainingName() {
		return trainingName;
	}
	public void setTrainingName(String trainingName) {
		this.trainingName = trainingName;
	}
	public int getAvailableSeats() {
		return AvailableSeats;
	}
	public void setAvailableSeats(int availableSeats) {
		AvailableSeats = availableSeats;
	}
	
	
	
	

}
